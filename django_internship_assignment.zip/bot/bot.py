import requests
from decouple import config

TOKEN = config("TELEGRAM_BOT_TOKEN")
URL = f"https://api.telegram.org/bot{TOKEN}"

def get_updates():
    return requests.get(f"{URL}/getUpdates").json()

def store_user(update):
    from core.models import TelegramUser
    message = update['message']
    username = message['from']['username']
    telegram_id = message['from']['id']
    TelegramUser.objects.get_or_create(telegram_username=username, telegram_id=telegram_id)

def handle_updates():
    updates = get_updates()
    for result in updates.get("result", []):
        message = result.get("message", {})
        text = message.get("text")
        if text == "/start":
            store_user(result)