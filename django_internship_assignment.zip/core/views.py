from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from rest_framework import status
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from .serializers import UserSerializer
from .tasks import send_welcome_email

@api_view(['GET'])
@permission_classes([AllowAny])
def public_view(request):
    return Response({"message": "This is a public endpoint"}, status=200)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def protected_view(request):
    serializer = UserSerializer(request.user)
    return Response(serializer.data)

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/')
    return render(request, 'login.html')