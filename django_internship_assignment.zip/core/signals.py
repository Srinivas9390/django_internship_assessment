from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from rest_framework.authtoken.models import Token
from .tasks import send_welcome_email

@receiver(post_save, sender=User)
def create_token_and_send_email(sender, instance: User, created: bool, **kwargs):
    if created:
        # Create DRF auth token
        Token.objects.create(user=instance)
        # Trigger async welcome email
        if instance.email:
            send_welcome_email.delay(instance.email)
